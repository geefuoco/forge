# Portability verification

Verdict: PASS for the assigned slice. No implementation edits were made.

Reviewed HEAD `c4e4610809b8c0fc50f07e3b01d8d031217200aa` plus the uncommitted restoration. Every hash in `.audit/resume-code-hashes.json` matches the reviewed files.

| File | SHA-256 |
| --- | --- |
| `.gitattributes` | `6b145762bcc255f35c6c4ebd42ed07d16960392e6d137f5ed22a3bea58eca1e9` |
| `scripts/neo-forge.mjs` | `14bae185eba498f6feab7de24685961f3bb30d670f12e7b7864035d5fd54f98f` |
| `scripts/neo-forge.test.mjs` | `ca08c1676682001bc0680c4df5a371a212da0e206543e223d74d0325cbf2bf2f` |
| `scripts/setup-forge-cloud.sh` | `0e72a90b2829aad6854ed5643c8dff5cf6498aea243271c4b74fee2b7febc9cd` |
| `evaluation/ai/decks/world-shaper.dck` | `bc6b2b88045e3efa8e1247d147bfcda2cf592196463006fe019883e6b1fcc793` |
| `evaluation/ai/decks/multiverse-reforged.dck` | `23ec69e88352e274c598a420fb7676e2606774b6768a2e728f786e120a011788` |

## Method and results

`node scripts/neo-forge.test.mjs` exited 0 with 16 passed tests and no failures, cancellations, or skips. The actual descendant test reported `process_stopped=true, tree_stopped=true`. Its live-PID control rejected the stopped-process assertion. The desktop receipt tests still require a live matching PID and reject another PID. Evidence is in [the independent test log](verify-portability-node-tests.log).

Source inspection at `scripts/neo-forge.mjs:289` confirms that Windows retains `.exe` while Linux selects native names. The runtime field accepts settings from the environment or toolchain file. Both Maven version observation and the package command call the same `mavenLauncherArgs`, which omits `-s` when no settings are configured. Windows execution was not available in this Linux environment.

The desktop argument list is read from the engine POM and supplied only by `play`. Missing options produce an explicit error. The headless evaluation command has no new module-access arguments. Real desktop and engine execution are assigned to verifier 2.

Both fixture files equal their exact upstream Git blobs and match their manifest SHA-256 values. World Shaper contains 2,371 bytes and Multiverse Reforged contains 2,760 bytes. `git check-attr` reports `text: unset` and `diff: unset` for both fixtures.

The setup script passed `bash -n`. Independent copies ran twice in each of four isolated project fixtures. Configuration bytes stayed identical. Existing cache directories, valid cache symlinks, and dangling cache symlinks were preserved. An absent cache became a symlink to `/workspace/.m2/repository`. The active checkout's toolchain and cache were not changed. Evidence is in [the checks log](verify-portability-checks.log).

The development instructions agree with the current command parser and setup script. The six attempts described there include two attempts of each mirror and both cross-deck orders. This review makes no claim about AI quality or deterministic replay.

## Comment review

The scoped executable changes add no prose comments or suppression directives. Deletion count is 0. Keep count is 0. `MUST KILL` count is 0. Restored comments, reruns, architecture sketches, fixes, encodings, and unenforced constraints are all 0. The shell shebang is an execution directive. No source changes are requested by this review.

Prove It Works required a fresh independent test run and exact fixture comparisons. These checks passed on the reviewed files. The parent owns the build, real games, desktop observation, and final evidence report.
