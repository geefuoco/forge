import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path('/workspace/forge')
checks = []
hashes = {}

def check(ok, label):
    checks.append({'pass': bool(ok), 'check': label})

def read(path):
    return json.loads((root / path).read_text())

def sha(path):
    path = root / path
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    hashes[str(path.relative_to(root))] = value
    return value

r = read('evaluation/ai/reports/2026-10-26-stock-smoke.json')
frozen = read('.audit/resume-code-hashes.json')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
check(head == frozen['head'] == 'c4e4610809b8c0fc50f07e3b01d8d031217200aa', 'exact HEAD')
for path, digest in frozen['sha256'].items():
    check(sha(path) == digest, f'frozen source {path}')
check(r['verification_source_hashes'] == frozen, 'published frozen source hashes')
b = read('.tools/eval-build-receipt.json')
for build in [b, r['build'], r['provenance']['build'], r['validation']['build']]:
    check(sha(build['jar']) == build['jar_sha256'], 'actual JAR matches build receipt')
    check(build['actual_head'] == head, 'build HEAD')
    check(build['runner_classes_sha256'] == b['runner_classes_sha256'], 'runner class receipt agreement')
    for path, digest in build['input_trees'].items():
        actual = subprocess.check_output(['git', 'rev-parse', f'HEAD:{path}'], cwd=root, text=True).strip()
        check(actual == digest, f'build input tree {path}')
    check(build['build_command'][-3:] == ['clean', 'package', '-DskipTests'], 'clean package command')
for name, digest in b['runner_classes_sha256'].items():
    check(sha('.tools/eval-classes/' + name) == digest, f'actual class {name}')
check(set(b['runner_classes_sha256']) == {p.name for p in (root / '.tools/eval-classes').glob('*.class')}, 'no extra runner classes')
check(sha('evaluation/ai/java/CommanderEval.java') == b['runner_source_sha256'], 'actual Java source')
for name, path in {'node': 'scripts/neo-forge.mjs', 'node_tests': 'scripts/neo-forge.test.mjs', 'java': 'evaluation/ai/java/CommanderEval.java', 'plan': 'evaluation/ai/plans/stock-smoke.json', 'manifest': 'evaluation/ai/deck-manifest.json'}.items():
    check(sha(path) == b['harness_sha256'][name] == r['build']['harness_sha256'][name], f'build source {name}')
run = pathlib.Path(r['run_directory'])
for name in ['request', 'provenance', 'summary']:
    check(read(run / (name + '.json')) == r[name], f'published {name} equals raw')
summary = r['summary']
check(summary['counts'] == {'completed': 6, 'timed_out': 0, 'crashed': 0, 'rejected': 0}, 'six clean completions')
check(summary['planned_games'] == summary['recorded_games'] == len(r['game_receipts']) == 6, 'six complete game records')
check(len({(tuple(j['seats']), j['seed']) for j in r['request']['jobs']}) == 4, 'four distinct matchup-seed inputs')
ai = {'profile': 'Default', 'monte_carlo': 'desktop-max', 'cheats': False, 'filtered_hands': False, 'ai_timeout_seconds': 5}
for game, result, job in zip(r['game_receipts'], summary['games'], r['request']['jobs']):
    directory = run / 'games' / game['id']
    for name in ['request', 'setup', 'started', 'terminal']:
        check(read(directory / (name + '.json')) == game[name], f'{game["id"]} published {name}')
    check(read(directory / 'result.json') == result, f'{game["id"]} result matches summary')
    req, setup, terminal = game['request'], game['setup'], game['terminal']
    check(setup['request_id'] == game['started']['request_id'] == terminal['request_id'] == req['id'], f'{game["id"]} matching receipt IDs')
    check(setup['status'] == 'ready' and game['started']['status'] == 'started' and terminal['status'] == 'terminal', f'{game["id"]} receipt states')
    check(setup['effective_ai'] == ai, f'{game["id"]} effective AI settings')
    check([s['deckId'] for s in req['seats']] == job['seats'] == result['seat_decks'] and req['seed'] == job['seed'] == result['seed'], f'{game["id"]} requested pairing and seed')
    check(len(req['seats']) == 2 and terminal['commander_life'] == [40, 40], f'{game["id"]} two seats at 40 starting life')
    check(terminal['terminal'] == 'win' and terminal['engine_end_reason'] == 'AllOpponentsLost' and result['outcome'] == 'completed', f'{game["id"]} natural terminal win')
    for key in ['terminal', 'winner_seat', 'engine_end_reason', 'last_turn', 'first_player_seat', 'game_log']:
        check(terminal[key] == result[key], f'{game["id"]} terminal/result {key}')
    check(not (root / directory / 'failure.json').exists(), f'{game["id"]} no failure receipt')
    for seat, loaded in zip(req['seats'], setup['seats']):
        check(sha(seat['deckFile']) == seat['expectedSha256'] == loaded['file_sha256'], f'{game["id"]} actual loaded deck hash')
        check(seat['totalCards'] == loaded['total_cards'] == 100 and seat['commander'] == loaded['commander'], f'{game["id"]} deck count and commander')
    check(sha(directory / 'assets/forge.profile.properties') == setup['profile_file_sha256'], f'{game["id"]} profile hash')
    for path in setup['paths'].values():
        check(pathlib.Path(path).resolve().is_relative_to((root / directory).resolve()), f'{game["id"]} writable path isolation')
    for name, record in game['logs'].items():
        path = directory / name
        check(sha(path) == record['sha256'] and (root / path).stat().st_size == record['bytes'], f'{game["id"]} {name} bytes/hash')
        check(not re.search(r'Exception|ERROR|Error:', (root / path).read_text()), f'{game["id"]} {name} diagnostic scan')
    log = (root / directory / 'game.log').read_text()
    check(f'Eval seat {terminal["winner_seat"]} has won because all opponents have lost' in log, f'{game["id"]} raw winner')
    turns = [int(x) for x in re.findall(r'^TURN\tTurn (\d+)', log, re.M)]
    check(max(turns) == terminal['last_turn'], f'{game["id"]} individual turn count')
validation_dir = pathlib.Path('.audit/ai-runs/validate-2026-10-26T19-49-12.296Z-a344cc5c')
check(read(validation_dir / 'validation.json') == r['validation'], 'published engine validation')
v = r['validation']['validation']
check(read(validation_dir / 'preflight/setup.json') == v, 'raw validation setup receipt')
check(v['status'] == 'ready' and v['effective_ai'] == ai and [s['total_cards'] for s in v['seats']] == [100, 100], 'validation ready with both 100-card decks')
check(sha(validation_dir / 'preflight/assets/forge.profile.properties') == v['profile_file_sha256'], 'validation profile hash')
for path in v['paths'].values():
    check(pathlib.Path(path).resolve().is_relative_to((root / validation_dir).resolve()), 'validation writable path isolation')
for name in ['stdout.log', 'stderr.log']:
    check(not re.search(r'Exception|ERROR|Error:', (root / validation_dir / 'preflight' / name).read_text()), 'validation diagnostic scan ' + name)
xml = root / '.audit/resume-jace-green.xml'
x = ET.parse(xml).getroot()
check([x.attrib[k] for k in ['tests', 'failures', 'errors', 'skipped']] == ['2', '0', '0', '0'], 'Jace XML passing counts')
check(sorted(t.attrib['name'] for t in x.findall('testcase')) == sorted(r['jace_regression']['cases']), 'Jace named cases')
check(sha(xml) == r['jace_regression']['xml_sha256'], 'published Jace XML hash')
check('Tests run: 2, Failures: 0, Errors: 0, Skipped: 0' in (root / '.audit/resume-jace-tests.log').read_text(), 'Maven confirms focused Jace suite')
current = None
excerpts = 0
for line in (root / 'evaluation/ai/reports/2026-10-26-decision-excerpts.txt').read_text().splitlines():
    if re.fullmatch('game-00[1-6]', line):
        current = line
        source = (root / run / 'games' / current / 'game.log').read_text().splitlines()
    match = re.match(r'^(\d+): (.*)$', line)
    if match:
        check(source[int(match[1]) - 1] == match[2], f'excerpt {current} line {match[1]}')
        excerpts += 1
d = r['desktop_verification']
check(d['startup_receipt'] == read('.tools/human-baseline/desktop-started.json'), 'desktop receipt exact')
check(d['startup_receipt']['effective_ai'] == ai, 'desktop AI settings')
check(sha('evaluation/ai/reports/' + d['screenshot']) == d['screenshot_sha256'], 'desktop screenshot hash')
check(d['window_observation'] == (root / '.audit/resume-desktop-windows.log').read_text(), 'desktop window observation exact')
check(d['stderr_sha256'] == sha('.tools/human-baseline/stderr.log'), 'desktop stderr hash')
check(d['stdout'] == (root / '.audit/resume-desktop.log').read_text(), 'desktop launcher stdout exact')
for directory in [root / run, root / validation_dir]:
    for path in directory.rglob('*.json'):
        sha(path)
for path in ['.tools/eval-build-receipt.json', '.tools/human-baseline/desktop-started.json', '.tools/human-baseline/play-request.json', '.audit/before-restore-validate.log', '.audit/restored-runner-before-tests.log', '.audit/restored-runner-tests.log', '.audit/verify-portability.md']:
    sha(path)
for path in ['docs/neo-forge/ai-runner-design.md', 'docs/neo-forge/issues.md', 'docs/neo-forge/v1-specification.md', 'docs/neo-forge/ai-baseline-report.md', 'docs/neo-forge/development.md', 'evaluation/ai/README.md']:
    text = (root / path).read_text()
    for link in re.findall(r'\]\(([^)]+)\)', text):
        if not re.match(r'https?://|#', link):
            check((root / path).parent.joinpath(link.split('#')[0]).exists(), f'doc link {path} -> {link}')
    sha(path)
for path in ['evaluation/ai/reports/2026-10-26-stock-smoke.json', 'evaluation/ai/reports/2026-10-26-decision-excerpts.txt', '.audit/resume-context.md', '.audit/resume-2026-10-26.tsv', '.audit/resume-build.log', '.audit/resume-jace-tests.log', '.audit/resume-jace-green.xml', '.audit/resume-validation.log', '.audit/resume-desktop.log', '.audit/resume-desktop-windows.log', '.audit/verify-evidence-desktop.log']:
    sha(path)
out = {'head': head, 'checks': checks, 'excerpt_lines': excerpts, 'hashes': hashes}
(root / '.audit/verify-evidence-checks.json').write_text(json.dumps(out, indent=2) + '\n')
failed = [c for c in checks if not c['pass']]
print(json.dumps({'checks': len(checks), 'passed': len(checks)-len(failed), 'failed': failed, 'excerpt_lines': excerpts, 'hashes': len(hashes)}, indent=2))
raise SystemExit(bool(failed))
